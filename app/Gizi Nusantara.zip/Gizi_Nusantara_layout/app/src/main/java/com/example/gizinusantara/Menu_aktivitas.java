package com.example.gizinusantara;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Menu_aktivitas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu__aktivitas);
    }
}
